# yolo12 > 2025-05-18 4:34pm
https://universe.roboflow.com/computervision-0uzfv/yolo12-euozk

Provided by a Roboflow user
License: CC BY 4.0

